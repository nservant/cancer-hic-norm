#include <R.h>
#include <Rinternals.h>
//static const double A_POSINF=(+1.0/0.0);
#define A_POSINF R_PosInf

