#ifndef CGHSEG_REPMAT_H
#define CGHSEG_REPMAT_H

#include "numlib.h"

namespace cghseg {

numlib_matrix *
repmat(numlib_matrix *, int, int);

}
#endif
